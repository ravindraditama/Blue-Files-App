import { BlueFileRecord } from '@/lib/supabase';
import { Package, PackageCheck, Layers, TrendingUp } from 'lucide-react';

interface DashboardProps {
  records: BlueFileRecord[];
  loading: boolean;
}

export function Dashboard({ records, loading }: DashboardProps) {
  const occupied = records.length;

  // Dynamic capacity: derive max rack/slot per area from data, then compute total
  const areaData = new Map<string, { maxRack: number; maxSlot: number }>();
  for (const r of records) {
    const existing = areaData.get(r.area);
    if (!existing) {
      areaData.set(r.area, { maxRack: r.rack, maxSlot: r.slot });
    } else {
      areaData.set(r.area, {
        maxRack: Math.max(existing.maxRack, r.rack),
        maxSlot: Math.max(existing.maxSlot, r.slot),
      });
    }
  }
  const totalCapacity = Array.from(areaData.values()).reduce((sum, { maxRack, maxSlot }) => sum + maxRack * 3 * maxSlot, 0);
  const empty = Math.max(0, totalCapacity - occupied);
  const utilization = totalCapacity > 0 ? (occupied / totalCapacity) * 100 : 0;

  const stats = [
    { label: 'Total Capacity', value: loading ? '—' : totalCapacity.toLocaleString(), icon: Layers, color: 'text-sky-400', bg: 'bg-sky-500/10', border: 'border-sky-500/20' },
    { label: 'Occupied Places', value: loading ? '—' : occupied.toLocaleString(), icon: Package, color: 'text-red-400', bg: 'bg-red-500/10', border: 'border-red-500/20' },
    { label: 'Empty Places', value: loading ? '—' : empty.toLocaleString(), icon: PackageCheck, color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
  ];

  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      {stats.map((s) => {
        const Icon = s.icon;
        return (
          <div key={s.label} className={`flex items-center gap-3 rounded-xl border ${s.border} ${s.bg} px-3 py-3 sm:px-4 ${stats.length === 3 && s.label === 'Empty Places' ? 'col-span-2 lg:col-span-1' : ''}`}>
            <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg ${s.bg} ${s.color}`}>
              <Icon className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <p className="truncate text-xs text-slate-400">{s.label}</p>
              <p className={`text-lg font-bold sm:text-xl ${s.color}`}>{s.value}</p>
            </div>
          </div>
        );
      })}

      <div className="col-span-2 rounded-xl border border-slate-800 bg-slate-900/50 px-4 py-3 lg:col-span-4">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1.5">
            <TrendingUp className="h-3.5 w-3.5" />
            Utilization Rate
          </span>
          <span className="font-semibold text-slate-300">{utilization.toFixed(1)}%</span>
        </div>
        <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-800">
          <div
            className="h-full rounded-full bg-gradient-to-r from-sky-500 to-blue-500 transition-all duration-500"
            style={{ width: `${utilization}%` }}
          />
        </div>
      </div>
    </div>
  );
}
