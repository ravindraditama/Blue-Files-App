import { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import { supabase, BlueFileRecord, parsePlace, BlueFileInput } from '@/lib/supabase';
import { X, UploadCloud, FileSpreadsheet, CheckCircle2, AlertTriangle, Loader2, ArrowUpCircle, PlusCircle } from 'lucide-react';

interface ImportModalProps {
  existingRecords: BlueFileRecord[];
  onClose: () => void;
  onImported: () => void;
  showToast: (msg: string, type?: 'success' | 'error') => void;
}

interface ParsedRow {
  no: number | null;
  wo: string;
  complete: string | null;
  place: string;
  date_in: string | null;
  time_in: string | null;
  pic: string | null;
}

export function ImportModal({ existingRecords, onClose, onImported, showToast }: ImportModalProps) {
  const [parsedRows, setParsedRows] = useState<ParsedRow[] | null>(null);
  const [fileName, setFileName] = useState('');
  const [importing, setImporting] = useState(false);
  const [results, setResults] = useState<{ inserted: number; updated: number; invalid: number; invalidRows: string[] } | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);

  const handleFile = async (file: File) => {
    setFileName(file.name);
    setResults(null);
    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array' });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const rawRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });

      const cleaned: ParsedRow[] = [];
      for (const row of rawRows) {
        const getVal = (keys: string[]): string => {
          for (const key of Object.keys(row)) {
            if (keys.some((k) => key.toLowerCase().replace(/\s+/g, '') === k.toLowerCase().replace(/\s+/g, ''))) {
              const v = row[key];
              if (v === null || v === undefined) return '';
              return String(v).trim();
            }
          }
          return '';
        };

        const noStr = getVal(['No', 'No.']);
        const no = noStr ? parseInt(noStr, 10) : null;
        const wo = getVal(['WO']);
        const complete = getVal(['Complete']);
        const place = getVal(['Place']);
        const dateIn = getVal(['DateIn', 'Date In', 'Date']);
        const timeIn = getVal(['TimeIn', 'Time In', 'Time']);
        const pic = getVal(['PIC']);

        if (!wo && !place) continue;

        cleaned.push({
          no: isNaN(no as number) ? null : no,
          wo: wo.toUpperCase(),
          complete: complete || null,
          place: place.toUpperCase().replace(/\s+/g, ''),
          date_in: dateIn || null,
          time_in: timeIn || null,
          pic: pic || null,
        });
      }

      setParsedRows(cleaned);
    } catch {
      showToast('Failed to read the Excel file. Please check the format.', 'error');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  const handleImport = async () => {
    if (!parsedRows) return;
    setImporting(true);

    // Build lookup maps from existing records
    const existingByWo = new Map<string, BlueFileRecord>();
    const existingByPlace = new Map<string, BlueFileRecord>();
    for (const r of existingRecords) {
      existingByWo.set(r.wo.toUpperCase(), r);
      existingByPlace.set(r.place.toUpperCase(), r);
    }

    const toInsert: BlueFileInput[] = [];
    const toUpdate: { id: string; input: BlueFileInput }[] = [];
    const invalidRows: string[] = [];
    const seenWo = new Set<string>();
    const seenPlace = new Set<string>();
    let inserted = 0;
    let updated = 0;

    for (const row of parsedRows) {
      const parsed = parsePlace(row.place);
      if (!parsed) {
        invalidRows.push(`Row ${row.no ?? '?'}: Invalid place "${row.place}"`);
        continue;
      }
      if (!row.wo) {
        invalidRows.push(`Row ${row.no ?? '?'}: Missing WO`);
        continue;
      }

      // Skip duplicates within the same import batch
      if (seenWo.has(row.wo)) {
        invalidRows.push(`Row ${row.no ?? '?'}: Duplicate WO "${row.wo}" within file`);
        continue;
      }
      if (seenPlace.has(parsed.place)) {
        invalidRows.push(`Row ${row.no ?? '?'}: Duplicate Place "${parsed.place}" within file`);
        continue;
      }
      seenWo.add(row.wo);
      seenPlace.add(parsed.place);

      const input: BlueFileInput = {
        no: row.no,
        wo: row.wo,
        complete: row.complete,
        place: parsed.place,
        area: parsed.area,
        rack: parsed.rack,
        position: parsed.position,
        slot: parsed.slot,
        date_in: row.date_in,
        time_in: row.time_in,
        pic: row.pic,
      };

      // Check if WO already exists in DB -> update
      const existingByWoMatch = existingByWo.get(row.wo);
      const existingByPlaceMatch = existingByPlace.get(parsed.place);

      if (existingByWoMatch) {
        toUpdate.push({ id: existingByWoMatch.id, input });
      } else if (existingByPlaceMatch) {
        // Place exists but with different WO -> update the place's record
        toUpdate.push({ id: existingByPlaceMatch.id, input });
      } else {
        toInsert.push(input);
      }
    }

    // Insert new records
    if (toInsert.length > 0) {
      const { error: insertError } = await supabase.from('blue_file_records').insert(toInsert);
      if (insertError) {
        showToast(insertError.message, 'error');
        setImporting(false);
        return;
      }
      inserted = toInsert.length;
    }

    // Update existing records one by one
    for (const { id, input } of toUpdate) {
      const { error: updateError } = await supabase.from('blue_file_records').update(input).eq('id', id);
      if (updateError) {
        showToast(updateError.message, 'error');
        setImporting(false);
        return;
      }
    }
    updated = toUpdate.length;

    setResults({ inserted, updated, invalid: invalidRows.length, invalidRows });
    setImporting(false);
    onImported();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />

      <div className="relative z-10 w-full max-w-2xl rounded-2xl border border-slate-700 bg-slate-900 shadow-2xl">
        <div className="flex items-start justify-between border-b border-slate-800 p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-500/10 ring-1 ring-inset ring-emerald-500/20">
              <FileSpreadsheet className="h-5 w-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="font-bold text-white">Import from Excel</h3>
              <p className="text-xs text-slate-400">Columns: No, WO, Complete, Place, Date In, Time In, PIC</p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-800 hover:text-slate-200">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="max-h-[65vh] overflow-y-auto p-5">
          {!parsedRows && !results && (
            <div
              onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={handleDrop}
              onClick={() => inputRef.current?.click()}
              className={`flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed p-12 text-center transition-all ${
                dragging ? 'border-emerald-500 bg-emerald-500/5' : 'border-slate-700 hover:border-slate-600'
              }`}
            >
              <UploadCloud className="h-12 w-12 text-slate-600" />
              <p className="mt-4 text-sm font-medium text-slate-300">Drop your Excel file here or click to browse</p>
              <p className="mt-1 text-xs text-slate-500">Supports .xlsx, .xls, .csv — existing records will be updated automatically</p>
              <input
                ref={inputRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
              />
            </div>
          )}

          {parsedRows && !results && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-sm text-slate-300">
                <FileSpreadsheet className="h-4 w-4 text-emerald-400" />
                <span className="font-medium">{fileName}</span>
                <span className="text-slate-500">— {parsedRows.length} rows detected</span>
              </div>

              <div className="overflow-hidden rounded-xl border border-slate-800">
                <div className="max-h-64 overflow-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="sticky top-0 bg-slate-800 text-slate-400">
                      <tr>
                        <th className="px-3 py-2 font-medium">No</th>
                        <th className="px-3 py-2 font-medium">WO</th>
                        <th className="px-3 py-2 font-medium">Place</th>
                        <th className="px-3 py-2 font-medium">PIC</th>
                        <th className="px-3 py-2 font-medium">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800">
                      {parsedRows.slice(0, 100).map((row, i) => {
                        const parsed = parsePlace(row.place);
                        const existingWo = existingRecords.some((r) => r.wo.toUpperCase() === row.wo);
                        const existingPlace = parsed && existingRecords.some((r) => r.place.toUpperCase() === parsed.place);
                        const willUpdate = existingWo || existingPlace;
                        const valid = parsed && row.wo;
                        return (
                          <tr key={i} className="bg-slate-900/50">
                            <td className="px-3 py-2 text-slate-400">{row.no ?? '—'}</td>
                            <td className="px-3 py-2 text-slate-200">{row.wo || <span className="text-red-400">missing</span>}</td>
                            <td className="px-3 py-2 text-slate-200">{row.place || <span className="text-red-400">missing</span>}</td>
                            <td className="px-3 py-2 text-slate-400">{row.pic || '—'}</td>
                            <td className="px-3 py-2">
                              {valid ? (
                                willUpdate ? (
                                  <span className="flex items-center gap-1 text-orange-400"><ArrowUpCircle className="h-3.5 w-3.5" /> Update</span>
                                ) : (
                                  <span className="flex items-center gap-1 text-emerald-400"><PlusCircle className="h-3.5 w-3.5" /> New</span>
                                )
                              ) : (
                                <span className="flex items-center gap-1 text-red-400"><AlertTriangle className="h-3.5 w-3.5" /> Invalid</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                {parsedRows.length > 100 && (
                  <div className="bg-slate-800/50 px-3 py-2 text-center text-xs text-slate-500">
                    Showing first 100 of {parsedRows.length} rows
                  </div>
                )}
              </div>

              <button
                onClick={handleImport}
                disabled={importing}
                className="flex w-full items-center justify-center gap-2 rounded-lg bg-emerald-500 px-5 py-3 text-sm font-semibold text-white transition hover:bg-emerald-400 disabled:opacity-50"
              >
                {importing ? <Loader2 className="h-4 w-4 animate-spin" /> : <UploadCloud className="h-4 w-4" />}
                {importing ? 'Importing...' : `Import ${parsedRows.length} rows`}
              </button>
            </div>
          )}

          {results && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <ResultCard label="New records" value={results.inserted} color="emerald" icon={PlusCircle} />
                <ResultCard label="Updated" value={results.updated} color="orange" icon={ArrowUpCircle} />
                <ResultCard label="Invalid" value={results.invalid} color="red" icon={AlertTriangle} />
              </div>

              {results.invalidRows.length > 0 && (
                <div className="rounded-lg border border-red-500/20 bg-red-500/5 p-3">
                  <p className="mb-1 text-xs font-semibold text-red-400">Invalid/skipped rows ({results.invalidRows.length}):</p>
                  <div className="space-y-0.5">
                    {results.invalidRows.slice(0, 10).map((r, i) => (
                      <p key={i} className="text-xs text-slate-400">{r}</p>
                    ))}
                    {results.invalidRows.length > 10 && <p className="text-xs text-slate-500">...and {results.invalidRows.length - 10} more</p>}
                  </div>
                </div>
              )}

              <button
                onClick={() => { setParsedRows(null); setResults(null); setFileName(''); }}
                className="w-full rounded-lg bg-slate-800 px-5 py-2.5 text-sm font-medium text-slate-300 transition hover:bg-slate-700"
              >
                Import another file
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ResultCard({ label, value, color, icon: Icon }: { label: string; value: number; color: 'emerald' | 'orange' | 'red'; icon: React.ElementType }) {
  const colors = {
    emerald: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
    orange: 'text-orange-400 bg-orange-500/10 border-orange-500/20',
    red: 'text-red-400 bg-red-500/10 border-red-500/20',
  };
  return (
    <div className={`rounded-xl border p-3 ${colors[color]}`}>
      <Icon className="h-5 w-5" />
      <p className="mt-2 text-2xl font-bold">{value}</p>
      <p className="text-xs text-slate-400">{label}</p>
    </div>
  );
}
