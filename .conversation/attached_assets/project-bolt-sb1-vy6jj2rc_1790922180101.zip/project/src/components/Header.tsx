import { FolderTree, Plus, UploadCloud } from 'lucide-react';

interface HeaderProps {
  onAddClick: () => void;
  onImportClick: () => void;
}

export function Header({ onAddClick, onImportClick }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-slate-800 bg-slate-950/95 backdrop-blur">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-sky-500 to-blue-600 shadow-lg shadow-sky-500/20">
              <FolderTree className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-white">Blue File Management</h1>
              <p className="text-xs text-slate-400">Storage monitoring & tracking system</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onImportClick}
              className="inline-flex items-center gap-2 rounded-lg bg-slate-800 px-3 py-2 text-sm font-medium text-slate-300 transition hover:bg-slate-700 active:scale-95"
            >
              <UploadCloud className="h-4 w-4" />
              <span className="hidden sm:inline">Import Excel</span>
            </button>
            <button
              onClick={onAddClick}
              className="inline-flex items-center gap-2 rounded-lg bg-sky-500 px-4 py-2 text-sm font-semibold text-white transition-all hover:bg-sky-400 hover:shadow-lg hover:shadow-sky-500/25 active:scale-95"
            >
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Add File</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
