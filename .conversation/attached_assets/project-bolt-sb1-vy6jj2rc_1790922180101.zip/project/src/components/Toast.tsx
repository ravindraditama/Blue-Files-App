import { CheckCircle2, AlertCircle } from 'lucide-react';

interface ToastProps {
  message: string;
  type: 'success' | 'error';
}

export function Toast({ message, type }: ToastProps) {
  const Icon = type === 'success' ? CheckCircle2 : AlertCircle;
  const colors = type === 'success' ? 'bg-emerald-600 border-emerald-500' : 'bg-red-600 border-red-500';

  return (
    <div className="fixed bottom-6 left-1/2 z-50 -translate-x-1/2 animate-fade-in-up">
      <div className={`flex items-center gap-3 rounded-xl border ${colors} px-5 py-3 shadow-2xl backdrop-blur`}>
        <Icon className="h-5 w-5 text-white" />
        <p className="text-sm font-medium text-white">{message}</p>
      </div>
    </div>
  );
}
