import { useState, useMemo } from 'react';
import { BlueFileRecord, BlueFileInput, parsePlace } from '@/lib/supabase';
import { X, FileText, MapPin, CheckCircle2 } from 'lucide-react';

interface AddFileModalProps {
  allRecords: BlueFileRecord[];
  defaultArea: string;
  onClose: () => void;
  onSave: (input: BlueFileInput) => Promise<boolean>;
}

export function AddFileModal({ allRecords, defaultArea, onClose, onSave }: AddFileModalProps) {
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    no: '',
    wo: '',
    complete: '',
    place: '',
    date_in: '',
    time_in: '',
    pic: '',
  });

  const existingWos = useMemo(() => new Set(allRecords.map((r) => r.wo.toUpperCase())), [allRecords]);
  const existingPlaces = useMemo(() => new Set(allRecords.map((r) => r.place.toUpperCase())), [allRecords]);

  const parsed = parsePlace(form.place);
  const placeNormalized = parsed?.place ?? '';
  const isDupWo = existingWos.has(form.wo.trim().toUpperCase());
  const isDupPlace = existingPlaces.has(placeNormalized.toUpperCase());
  const canSave = form.wo.trim() && parsed && !isDupWo && !isDupPlace;

  const handleSave = async () => {
    if (!canSave || !parsed) return;
    setSaving(true);
    const input: BlueFileInput = {
      no: form.no ? parseInt(form.no, 10) : null,
      wo: form.wo.trim().toUpperCase(),
      complete: form.complete.trim() || null,
      place: parsed.place,
      area: parsed.area,
      rack: parsed.rack,
      position: parsed.position,
      slot: parsed.slot,
      date_in: form.date_in.trim() || null,
      time_in: form.time_in.trim() || null,
      pic: form.pic.trim() || null,
    };
    const ok = await onSave(input);
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />

      <div className="relative z-10 w-full max-w-lg rounded-2xl border border-slate-700 bg-slate-900 shadow-2xl">
        <div className="flex items-start justify-between border-b border-slate-800 p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-sky-500/10 ring-1 ring-inset ring-sky-500/20">
              <FileText className="h-5 w-5 text-sky-400" />
            </div>
            <div>
              <h3 className="font-bold text-white">Add Blue File</h3>
              <p className="text-xs text-slate-400">Manually create a new record</p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-800 hover:text-slate-200">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="max-h-[60vh] overflow-y-auto p-5">
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Field label="No">
                <input type="number" value={form.no} onChange={(e) => setForm({ ...form, no: e.target.value })}
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-100 focus:border-sky-500 focus:outline-none" />
              </Field>
              <Field label="WO" required>
                <input type="text" value={form.wo} onChange={(e) => setForm({ ...form, wo: e.target.value.toUpperCase() })}
                  placeholder="e.g. WO-2024-001"
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-100 placeholder-slate-500 focus:border-sky-500 focus:outline-none" />
                {isDupWo && <p className="mt-1 text-xs text-red-400">WO already exists</p>}
              </Field>
            </div>

            <Field label="Place" required>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
                <input type="text" value={form.place} onChange={(e) => setForm({ ...form, place: e.target.value.toUpperCase().replace(/\s+/g, '') })}
                  placeholder="e.g. A16R-001"
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 pl-10 font-mono text-sm text-slate-100 placeholder-slate-500 focus:border-sky-500 focus:outline-none" />
              </div>
              {form.place && !parsed && <p className="mt-1 text-xs text-red-400">Invalid format. Use like A16R-001 (Area+Rack+Position-Slot)</p>}
              {isDupPlace && <p className="mt-1 text-xs text-red-400">Place already assigned</p>}
              {parsed && !isDupPlace && (
                <p className="mt-1 flex items-center gap-1 text-xs text-emerald-400">
                  <CheckCircle2 className="h-3 w-3" /> {parsed.place} — Area {parsed.area}, Rack {parsed.rack}, Pos {parsed.position}, Slot {parsed.slot}
                </p>
              )}
            </Field>

            <div className="grid grid-cols-3 gap-3">
              <Field label="Complete">
                <input type="text" value={form.complete} onChange={(e) => setForm({ ...form, complete: e.target.value })}
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-100 focus:border-sky-500 focus:outline-none" />
              </Field>
              <Field label="Date In">
                <input type="text" value={form.date_in} onChange={(e) => setForm({ ...form, date_in: e.target.value })}
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-100 focus:border-sky-500 focus:outline-none" />
              </Field>
              <Field label="Time In">
                <input type="text" value={form.time_in} onChange={(e) => setForm({ ...form, time_in: e.target.value })}
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-100 focus:border-sky-500 focus:outline-none" />
              </Field>
            </div>

            <Field label="PIC">
              <input type="text" value={form.pic} onChange={(e) => setForm({ ...form, pic: e.target.value })}
                className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-100 focus:border-sky-500 focus:outline-none" />
            </Field>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 border-t border-slate-800 p-5">
          <button onClick={onClose} className="rounded-lg bg-slate-800 px-5 py-2.5 text-sm font-medium text-slate-300 transition hover:bg-slate-700">Cancel</button>
          <button onClick={handleSave} disabled={!canSave || saving} className="rounded-lg bg-sky-500 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-sky-400 disabled:cursor-not-allowed disabled:opacity-50">
            {saving ? 'Saving...' : 'Add File'}
          </button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-xs font-medium text-slate-400">
        {label} {required && <span className="text-red-400">*</span>}
      </label>
      {children}
    </div>
  );
}
