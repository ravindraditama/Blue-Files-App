import { Search, X, FileText, MapPin, User } from 'lucide-react';

type SearchType = 'wo' | 'place' | 'pic';

interface SearchBarProps {
  searchType: SearchType;
  setSearchType: (type: SearchType) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onSearch: () => void;
}

export function SearchBar({ searchType, setSearchType, searchQuery, setSearchQuery, onSearch }: SearchBarProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch();
  };

  const tabs: { type: SearchType; label: string; icon: React.ElementType }[] = [
    { type: 'wo', label: 'WO', icon: FileText },
    { type: 'place', label: 'Place', icon: MapPin },
    { type: 'pic', label: 'PIC', icon: User },
  ];

  const placeholders: Record<SearchType, string> = {
    wo: 'e.g. WO-2024-001',
    place: 'e.g. A16R-001',
    pic: 'e.g. John Doe',
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-2 sm:flex-row sm:items-center">
      <div className="flex rounded-lg bg-slate-800 p-1">
        {tabs.map(({ type, label, icon: Icon }) => (
          <button
            key={type}
            type="button"
            onClick={() => setSearchType(type)}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-all ${
              searchType === type ? 'bg-sky-500 text-white shadow' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Icon className="h-3.5 w-3.5" />
            {label}
          </button>
        ))}
      </div>

      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder={placeholders[searchType]}
          className="w-full rounded-lg border border-slate-700 bg-slate-800 py-2.5 pl-10 pr-10 text-sm text-slate-100 placeholder-slate-500 transition focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/20"
        />
        {searchQuery && (
          <button type="button" onClick={() => setSearchQuery('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      <button type="submit" className="rounded-lg bg-sky-500 px-6 py-2.5 text-sm font-semibold text-white transition-all hover:bg-sky-400 hover:shadow-lg hover:shadow-sky-500/25 active:scale-95">
        Search
      </button>
    </form>
  );
}
