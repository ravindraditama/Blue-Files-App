import { BlueFileRecord, POSITIONS } from '@/lib/supabase';
import { useState, useMemo, useEffect } from 'react';
import { ChevronRight, MapPin, FileText, User, Calendar, Package, PackageCheck, X } from 'lucide-react';

interface RackMapProps {
  records: BlueFileRecord[];
  selectedArea: string;
  onSelectArea: (area: string) => void;
  highlightPlace: string | null;
  onSlotClick: (record: BlueFileRecord | null, place: string) => void;
}

export function RackMap({ records, selectedArea, onSelectArea, highlightPlace, onSlotClick }: RackMapProps) {
  const [openRack, setOpenRack] = useState<number | null>(null);
  const [infoSlot, setInfoSlot] = useState<{ record: BlueFileRecord | null; place: string } | null>(null);

  const structure = useMemo(() => {
    const areaMap = new Map<string, { racks: Set<number>; maxSlot: number; count: number }>();
    for (const r of records) {
      const ex = areaMap.get(r.area);
      if (!ex) {
        areaMap.set(r.area, { racks: new Set([r.rack]), maxSlot: r.slot, count: 1 });
      } else {
        ex.racks.add(r.rack);
        ex.maxSlot = Math.max(ex.maxSlot, r.slot);
        ex.count++;
      }
    }
    return Array.from(areaMap.entries()).sort(([a], [b]) => a.localeCompare(b));
  }, [records]);

  const areaRecords = useMemo(() => {
    const map = new Map<string, BlueFileRecord>();
    for (const r of records) {
      if (r.area === selectedArea) map.set(`${r.rack}-${r.position}-${r.slot}`, r);
    }
    return map;
  }, [records, selectedArea]);

  const areaInfo = structure.find(([a]) => a === selectedArea);
  const areaRacks = areaInfo ? Array.from(areaInfo[1].racks).sort((a, b) => a - b) : [];
  const maxSlot = areaInfo?.[1].maxSlot ?? 0;

  useEffect(() => {
    setOpenRack(areaRacks.length > 0 ? areaRacks[0] : null);
    setInfoSlot(null);
  }, [selectedArea]);

  if (structure.length === 0) {
    return (
      <div className="mt-6 flex flex-col items-center justify-center rounded-2xl border border-slate-800 bg-slate-900/50 p-12 text-center">
        <p className="text-sm text-slate-500">No data yet. Import an Excel file or add a file manually to see the rack map.</p>
      </div>
    );
  }

  if (areaRacks.length === 0) {
    return (
      <div className="mt-6 flex flex-col items-center justify-center rounded-2xl border border-slate-800 bg-slate-900/50 p-12 text-center">
        <p className="text-sm text-slate-500">Area {selectedArea} has no records.</p>
      </div>
    );
  }

  const slots = Array.from({ length: maxSlot }, (_, i) => i + 1);

  const rackCount = (rackNum: number) => {
    let count = 0;
    for (const r of records) if (r.area === selectedArea && r.rack === rackNum) count++;
    return count;
  };

  const handleSlotClick = (record: BlueFileRecord | null, place: string) => {
    if (record) {
      onSlotClick(record, place);
    } else {
      setInfoSlot({ record: null, place });
    }
  };

  return (
    <div className="mt-4 space-y-4">
      {/* Area tabs — dynamically generated from data */}
      <div>
        <div className="mb-2 flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-slate-500">
          <span>Areas</span>
          <span className="text-slate-600">({structure.length} found in data)</span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {structure.map(([area, info]) => {
            const isActive = selectedArea === area;
            return (
              <button
                key={area}
                onClick={() => onSelectArea(area)}
                className={`relative min-w-[2.5rem] rounded-lg px-4 py-2.5 text-base font-bold transition-all duration-200 ${
                  isActive ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/30' : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-slate-200'
                }`}
              >
                {area}
                {info.count > 0 && (
                  <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-bold text-white ring-2 ring-slate-900">
                    {info.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Area header */}
      <div className="flex items-center gap-2">
        <h2 className="text-lg font-bold text-white">Area {selectedArea}</h2>
        <span className="rounded-md bg-slate-800 px-2.5 py-1 text-xs font-medium text-slate-400">
          {areaRacks.length} rack{areaRacks.length !== 1 ? 's' : ''} · max {maxSlot} slot{maxSlot !== 1 ? 's' : ''} · 3 positions (L/M/R)
        </span>
      </div>

      {/* Rack visualization */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-3 sm:p-4">
        {/* Rack number buttons — dynamically from data */}
        <div className="mb-2 flex items-center gap-2 text-xs text-slate-500">
          <span className="font-medium uppercase tracking-wide">Racks</span>
          <span className="text-slate-600">({areaRacks.length} found · click to expand)</span>
        </div>
        <div className="grid grid-cols-6 gap-1.5 sm:grid-cols-8 md:grid-cols-10 lg:grid-cols-12 xl:grid-cols-14">
          {areaRacks.map((rackNum) => {
            const isOpen = openRack === rackNum;
            const count = rackCount(rackNum);
            return (
              <button
                key={rackNum}
                onClick={() => { setOpenRack(isOpen ? null : rackNum); setInfoSlot(null); }}
                className={`relative flex flex-col items-center rounded-lg py-2.5 text-sm font-bold transition-all duration-200 ${
                  isOpen ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/25' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <span>{String(rackNum).padStart(2, '0')}</span>
                {count > 0 && (
                  <span className={`mt-0.5 text-[9px] font-medium ${isOpen ? 'text-sky-100' : 'text-slate-500'}`}>
                    {count} file{count !== 1 ? 's' : ''}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Expanded rack: Area → Rack → L/M/R → Slots */}
        {openRack !== null && (
          <div className="mt-4 animate-fade-in-up">
            <div className="mb-3 flex items-center gap-2">
              <span className="rounded-md bg-sky-500/20 px-3 py-1 text-xs font-bold text-sky-400">
                {selectedArea}{String(openRack).padStart(2, '0')}
              </span>
              <ChevronRight className="h-4 w-4 text-slate-600" />
              <span className="text-xs text-slate-500">L / M / R</span>
              <ChevronRight className="h-4 w-4 text-slate-600" />
              <span className="text-xs text-slate-500">{maxSlot} slots</span>
              <div className="h-px flex-1 bg-slate-800" />
            </div>

            {/* Three position columns side by side */}
            <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
              {POSITIONS.map((pos) => {
                const posSlots = slots.map((slot) => ({
                  slot,
                  record: areaRecords.get(`${openRack}-${pos}-${slot}`) ?? null,
                }));
                const posOccupied = posSlots.filter((s) => s.record).length;
                const posFree = maxSlot - posOccupied;

                return (
                  <div key={pos} className="rounded-xl border border-slate-700 bg-slate-950/50 p-3">
                    {/* Position header */}
                    <div className="mb-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="flex h-7 w-7 items-center justify-center rounded-md bg-slate-800 text-xs font-bold text-sky-400">
                          {pos}
                        </div>
                        <span className="text-xs font-semibold text-slate-400">Position {pos}</span>
                      </div>
                      <div className="flex items-center gap-2 text-[10px]">
                        <span className="flex items-center gap-1 text-red-400">
                          <span className="h-2 w-2 rounded-sm bg-red-500" />
                          {posOccupied}
                        </span>
                        <span className="flex items-center gap-1 text-emerald-400">
                          <span className="h-2 w-2 rounded-sm bg-emerald-500/40 ring-1 ring-emerald-500/30" />
                          {posFree}
                        </span>
                      </div>
                    </div>

                    {/* Slot boxes */}
                    <div className="grid grid-cols-5 gap-1.5 sm:grid-cols-8 md:grid-cols-5 lg:grid-cols-8 xl:grid-cols-10">
                      {posSlots.map(({ slot, record }) => {
                        const place = record
                          ? record.place
                          : `${selectedArea}${openRack}${pos}-${String(slot).padStart(3, '0')}`;
                        const isHighlighted = highlightPlace === place;

                        return (
                          <button
                            key={slot}
                            onClick={() => handleSlotClick(record, place)}
                            title={record ? `${record.wo} · ${place}` : `Available · ${place}`}
                            className={`group relative flex aspect-square items-center justify-center rounded-md text-[8px] font-bold transition-all duration-150 sm:text-[9px] ${
                              record
                                ? 'bg-gradient-to-br from-red-500 to-red-600 text-white shadow-sm shadow-red-500/20 hover:from-red-400 hover:to-red-500 hover:shadow-md hover:shadow-red-500/30 active:scale-95'
                                : 'bg-emerald-500/15 text-emerald-600 ring-1 ring-inset ring-emerald-500/20 hover:bg-emerald-500/25 hover:ring-emerald-500/40 active:scale-95'
                            } ${isHighlighted ? 'z-20 scale-110 ring-2 ring-sky-400 ring-offset-1 ring-offset-slate-950' : ''}`}
                          >
                            {String(slot).padStart(3, '0')}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Info panel for clicked empty slot */}
            {infoSlot && !infoSlot.record && (
              <div className="mt-3 flex items-center justify-between rounded-lg border border-emerald-500/20 bg-emerald-500/5 px-4 py-3">
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/10 ring-1 ring-inset ring-emerald-500/20">
                    <PackageCheck className="h-4 w-4 text-emerald-400" />
                  </div>
                  <div>
                    <p className="font-mono text-sm font-semibold text-sky-400">{infoSlot.place}</p>
                    <p className="text-xs text-emerald-400">Available — no file assigned</p>
                  </div>
                </div>
                <button onClick={() => setInfoSlot(null)} className="rounded-md p-1 text-slate-500 transition hover:bg-slate-800 hover:text-slate-300">
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}

            {/* Info panel for clicked occupied slot (inline quick view) */}
            {infoSlot?.record && (
              <div className="mt-3 flex items-center justify-between rounded-lg border border-red-500/20 bg-red-500/5 px-4 py-3">
                <div className="flex items-center gap-4">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-red-500/10 ring-1 ring-inset ring-red-500/20">
                    <Package className="h-4 w-4 text-red-400" />
                  </div>
                  <div className="flex flex-wrap items-center gap-x-5 gap-y-1 text-xs">
                    <span className="flex items-center gap-1.5">
                      <FileText className="h-3.5 w-3.5 text-slate-500" />
                      <span className="text-slate-500">WO:</span>
                      <span className="font-semibold text-slate-200">{infoSlot.record.wo}</span>
                    </span>
                    <span className="flex items-center gap-1.5">
                      <MapPin className="h-3.5 w-3.5 text-slate-500" />
                      <span className="text-slate-500">Place:</span>
                      <span className="font-mono font-semibold text-sky-400">{infoSlot.place}</span>
                    </span>
                    {infoSlot.record.pic && (
                      <span className="flex items-center gap-1.5">
                        <User className="h-3.5 w-3.5 text-slate-500" />
                        <span className="text-slate-500">PIC:</span>
                        <span className="text-slate-300">{infoSlot.record.pic}</span>
                      </span>
                    )}
                    {infoSlot.record.date_in && (
                      <span className="flex items-center gap-1.5">
                        <Calendar className="h-3.5 w-3.5 text-slate-500" />
                        <span className="text-slate-500">Date In:</span>
                        <span className="text-slate-300">{infoSlot.record.date_in}</span>
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => { onSlotClick(infoSlot.record!, infoSlot.place); setInfoSlot(null); }}
                    className="rounded-md bg-sky-500/20 px-3 py-1.5 text-xs font-medium text-sky-400 transition hover:bg-sky-500/30"
                  >
                    Details
                  </button>
                  <button onClick={() => setInfoSlot(null)} className="rounded-md p-1 text-slate-500 transition hover:bg-slate-800 hover:text-slate-300">
                    <X className="h-4 w-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-4 rounded-xl border border-slate-800 bg-slate-900/50 px-4 py-3 sm:gap-6">
        <div className="flex items-center gap-2">
          <div className="h-4 w-4 rounded bg-gradient-to-br from-red-500 to-red-600" />
          <span className="text-xs text-slate-400">Occupied</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-4 w-4 rounded bg-emerald-500/15 ring-1 ring-inset ring-emerald-500/20" />
          <span className="text-xs text-slate-400">Available</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="h-4 w-4 rounded bg-slate-800 ring-2 ring-sky-400 ring-offset-1 ring-offset-slate-950" />
          <span className="text-xs text-slate-400">Search result</span>
        </div>
        <div className="ml-auto text-xs text-slate-500">
          Click any slot for details
        </div>
      </div>
    </div>
  );
}
