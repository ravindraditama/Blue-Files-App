import { useState } from 'react';
import { BlueFileRecord, BlueFileInput, parsePlace } from '@/lib/supabase';
import { X, FileText, MapPin, Calendar, Clock, User, Edit2, Trash2, AlertTriangle, Move, Hash } from 'lucide-react';

interface FileDetailModalProps {
  record: BlueFileRecord;
  allRecords: BlueFileRecord[];
  onClose: () => void;
  onEdit: (input: BlueFileInput, id: string) => Promise<boolean>;
  onDelete: (id: string) => Promise<boolean>;
  onMove: (id: string, newPlace: string) => Promise<boolean>;
}

export function FileDetailModal({ record, allRecords, onClose, onEdit, onDelete, onMove }: FileDetailModalProps) {
  const [mode, setMode] = useState<'view' | 'edit' | 'move' | 'delete'>('view');
  const [saving, setSaving] = useState(false);
  const [movePlace, setMovePlace] = useState('');
  const [form, setForm] = useState<BlueFileInput>({
    no: record.no,
    wo: record.wo,
    complete: record.complete,
    place: record.place,
    area: record.area,
    rack: record.rack,
    position: record.position,
    slot: record.slot,
    date_in: record.date_in,
    time_in: record.time_in,
    pic: record.pic,
  });

  const occupiedPlaces = new Set(allRecords.filter((r) => r.id !== record.id).map((r) => r.place.toUpperCase()));
  const moveParsed = parsePlace(movePlace);
  const movePlaceNormalized = moveParsed?.place ?? '';
  const moveTargetOccupied = occupiedPlaces.has(movePlaceNormalized.toUpperCase());
  const canMove = moveParsed && !moveTargetOccupied;

  const handleSave = async () => {
    setSaving(true);
    const ok = await onEdit(form, record.id);
    setSaving(false);
    if (ok) setMode('view');
  };

  const handleMove = async () => {
    if (!canMove) return;
    setSaving(true);
    const ok = await onMove(record.id, movePlaceNormalized);
    setSaving(false);
    if (ok) setMode('view');
  };

  const handleDelete = async () => {
    setSaving(true);
    await onDelete(record.id);
    setSaving(false);
  };

  const dupWo = allRecords.some((r) => r.id !== record.id && r.wo.toUpperCase() === form.wo.trim().toUpperCase());
  const parsedFormPlace = parsePlace(form.place);
  const dupPlace = allRecords.some((r) => r.id !== record.id && r.place.toUpperCase() === (parsedFormPlace?.place ?? form.place).toUpperCase());
  const canSave = form.wo.trim() && parsedFormPlace && !dupWo && !dupPlace;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />

      <div className="relative z-10 w-full max-w-lg rounded-2xl border border-slate-700 bg-slate-900 shadow-2xl">
        <div className="flex items-start justify-between border-b border-slate-800 p-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-red-500/10 ring-1 ring-inset ring-red-500/20">
              <FileText className="h-5 w-5 text-red-400" />
            </div>
            <div>
              <h3 className="font-bold text-white">{record.wo}</h3>
              <p className="text-xs text-slate-400">Blue File Record</p>
            </div>
          </div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-800 hover:text-slate-200">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="max-h-[60vh] overflow-y-auto p-5">
          {mode === 'delete' && (
            <div className="flex flex-col items-center text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-red-500/10 ring-1 ring-inset ring-red-500/30">
                <AlertTriangle className="h-7 w-7 text-red-400" />
              </div>
              <h4 className="mt-4 text-lg font-bold text-white">Remove this record?</h4>
              <p className="mt-2 max-w-sm text-sm text-slate-400">
                WO "{record.wo}" at {record.place} will be permanently deleted. The slot will become available (green).
              </p>
              <div className="mt-6 flex gap-3">
                <button onClick={() => setMode('view')} className="rounded-lg bg-slate-800 px-5 py-2.5 text-sm font-medium text-slate-300 transition hover:bg-slate-700">Cancel</button>
                <button onClick={handleDelete} disabled={saving} className="rounded-lg bg-red-500 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-red-400 disabled:opacity-50">
                  {saving ? 'Removing...' : 'Remove'}
                </button>
              </div>
            </div>
          )}

          {mode === 'move' && (
            <div className="space-y-4">
              <div className="rounded-lg border border-slate-800 bg-slate-950/50 p-3">
                <p className="text-xs text-slate-500">Current location</p>
                <p className="font-mono text-sm text-sky-400">{record.place}</p>
              </div>
              <div>
                <label className="mb-1 block text-xs font-medium text-slate-400">New location (e.g. B05L-003)</label>
                <input
                  type="text"
                  value={movePlace}
                  onChange={(e) => setMovePlace(e.target.value.toUpperCase().replace(/\s+/g, ''))}
                  placeholder="Enter new place code"
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 font-mono text-sm text-slate-100 placeholder-slate-500 focus:border-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500/20"
                />
                {movePlace && !moveParsed && <p className="mt-1 text-xs text-red-400">Invalid format. Use like A16R-001</p>}
                {moveTargetOccupied && <p className="mt-1 text-xs text-red-400">This location is already occupied</p>}
                {canMove && <p className="mt-1 text-xs text-emerald-400">{movePlaceNormalized} is available</p>}
              </div>
              <div className="flex justify-end gap-3">
                <button onClick={() => setMode('view')} className="rounded-lg bg-slate-800 px-5 py-2.5 text-sm font-medium text-slate-300 transition hover:bg-slate-700">Cancel</button>
                <button onClick={handleMove} disabled={!canMove || saving} className="rounded-lg bg-sky-500 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-sky-400 disabled:opacity-50">
                  {saving ? 'Moving...' : 'Move File'}
                </button>
              </div>
            </div>
          )}

          {mode === 'edit' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <EditField label="No">
                  <input type="number" value={form.no ?? ''} onChange={(e) => setForm({ ...form, no: e.target.value ? parseInt(e.target.value, 10) : null })}
                    className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-100 focus:border-sky-500 focus:outline-none" />
                </EditField>
                <EditField label="WO" required>
                  <input type="text" value={form.wo} onChange={(e) => setForm({ ...form, wo: e.target.value.toUpperCase() })}
                    className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-100 focus:border-sky-500 focus:outline-none" />
                  {dupWo && <p className="mt-1 text-xs text-red-400">WO already exists</p>}
                </EditField>
              </div>
              <EditField label="Place" required>
                <input type="text" value={form.place} onChange={(e) => setForm({ ...form, place: e.target.value.toUpperCase().replace(/\s+/g, '') })}
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 font-mono text-sm text-slate-100 focus:border-sky-500 focus:outline-none" />
                {form.place && !parsedFormPlace && <p className="mt-1 text-xs text-red-400">Invalid format. Use like A16R-001</p>}
                {dupPlace && <p className="mt-1 text-xs text-red-400">Place already assigned</p>}
              </EditField>
              <div className="grid grid-cols-3 gap-3">
                <EditField label="Complete">
                  <input type="text" value={form.complete ?? ''} onChange={(e) => setForm({ ...form, complete: e.target.value })}
                    className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-100 focus:border-sky-500 focus:outline-none" />
                </EditField>
                <EditField label="Date In">
                  <input type="text" value={form.date_in ?? ''} onChange={(e) => setForm({ ...form, date_in: e.target.value })}
                    className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-100 focus:border-sky-500 focus:outline-none" />
                </EditField>
                <EditField label="Time In">
                  <input type="text" value={form.time_in ?? ''} onChange={(e) => setForm({ ...form, time_in: e.target.value })}
                    className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-100 focus:border-sky-500 focus:outline-none" />
                </EditField>
              </div>
              <EditField label="PIC">
                <input type="text" value={form.pic ?? ''} onChange={(e) => setForm({ ...form, pic: e.target.value })}
                  className="w-full rounded-lg border border-slate-700 bg-slate-800 px-3 py-2 text-sm text-slate-100 focus:border-sky-500 focus:outline-none" />
              </EditField>
              <div className="flex justify-end gap-3">
                <button onClick={() => setMode('view')} className="rounded-lg bg-slate-800 px-5 py-2.5 text-sm font-medium text-slate-300 transition hover:bg-slate-700">Cancel</button>
                <button onClick={handleSave} disabled={!canSave || saving} className="rounded-lg bg-sky-500 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-sky-400 disabled:opacity-50">
                  {saving ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </div>
          )}

          {mode === 'view' && (
            <div className="space-y-3">
              <DetailRow icon={MapPin} label="Place">
                <span className="font-mono text-sm text-sky-400">{record.place}</span>
              </DetailRow>
              <DetailRow icon={Hash} label="No">
                <span className="text-sm text-slate-200">{record.no ?? '—'}</span>
              </DetailRow>
              {record.complete && (
                <DetailRow icon={FileText} label="Complete">
                  <span className="text-sm text-slate-200">{record.complete}</span>
                </DetailRow>
              )}
              <div className="grid grid-cols-2 gap-3">
                <DetailRow icon={Calendar} label="Date In">
                  <span className="text-sm text-slate-200">{record.date_in ?? '—'}</span>
                </DetailRow>
                <DetailRow icon={Clock} label="Time In">
                  <span className="text-sm text-slate-200">{record.time_in ?? '—'}</span>
                </DetailRow>
              </div>
              <DetailRow icon={User} label="PIC">
                <span className="text-sm text-slate-200">{record.pic ?? '—'}</span>
              </DetailRow>
            </div>
          )}
        </div>

        {mode === 'view' && (
          <div className="flex flex-wrap items-center justify-end gap-2 border-t border-slate-800 p-5">
            <button onClick={() => setMode('delete')} className="inline-flex items-center gap-2 rounded-lg bg-red-500/10 px-4 py-2.5 text-sm font-medium text-red-400 ring-1 ring-inset ring-red-500/20 transition hover:bg-red-500/20">
              <Trash2 className="h-4 w-4" /> Remove
            </button>
            <button onClick={() => setMode('move')} className="inline-flex items-center gap-2 rounded-lg bg-sky-500/10 px-4 py-2.5 text-sm font-medium text-sky-400 ring-1 ring-inset ring-sky-500/20 transition hover:bg-sky-500/20">
              <Move className="h-4 w-4" /> Move
            </button>
            <button onClick={() => setMode('edit')} className="inline-flex items-center gap-2 rounded-lg bg-sky-500 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-sky-400">
              <Edit2 className="h-4 w-4" /> Edit
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function DetailRow({ icon: Icon, label, children }: { icon: React.ElementType; label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-slate-800">
        <Icon className="h-4 w-4 text-slate-500" />
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-xs text-slate-500">{label}</p>
        {children}
      </div>
    </div>
  );
}

function EditField({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-xs font-medium text-slate-400">
        {label} {required && <span className="text-red-400">*</span>}
      </label>
      {children}
    </div>
  );
}
