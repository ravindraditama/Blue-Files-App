import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface BlueFileRecord {
  id: string;
  no: number | null;
  wo: string;
  complete: string | null;
  place: string;
  area: string;
  rack: number;
  position: string;
  slot: number;
  date_in: string | null;
  time_in: string | null;
  pic: string | null;
  created_at: string;
  updated_at: string;
}

export interface BlueFileInput {
  no?: number | null;
  wo: string;
  complete?: string | null;
  place: string;
  area: string;
  rack: number;
  position: string;
  slot: number;
  date_in?: string | null;
  time_in?: string | null;
  pic?: string | null;
}

export interface ParsedPlace {
  area: string;
  rack: number;
  position: string;
  slot: number;
  place: string;
}

// Parse a place code like "A16R-001" or "N16R-028" into components.
// Format: <Area letter(s)><Rack number><Position letter>-<Slot number>
export function parsePlace(place: string): ParsedPlace | null {
  const trimmed = place.trim().toUpperCase();
  const match = trimmed.match(/^([A-Z]+)(\d+)([LMR])-(\d+)$/);
  if (!match) return null;
  const area = match[1];
  const rack = parseInt(match[2], 10);
  const position = match[3];
  const slot = parseInt(match[4], 10);
  return { area, rack, position, slot, place: `${area}${rack}${position}-${String(slot).padStart(3, '0')}` };
}

export function formatPlace(area: string, rack: number, position: string, slot: number): string {
  return `${area}${rack}${position}-${String(slot).padStart(3, '0')}`;
}

export const POSITIONS = ['L', 'M', 'R'] as const;
