import { useState, useEffect, useCallback } from 'react';
import { supabase, BlueFileRecord, BlueFileInput, parsePlace } from '@/lib/supabase';
import { Header } from '@/components/Header';
import { SearchBar } from '@/components/SearchBar';
import { Dashboard } from '@/components/Dashboard';
import { RackMap } from '@/components/RackMap';
import { FileDetailModal } from '@/components/FileDetailModal';
import { AddFileModal } from '@/components/AddFileModal';
import { ImportModal } from '@/components/ImportModal';
import { Toast } from '@/components/Toast';
import { FileSpreadsheet } from 'lucide-react';

type SearchType = 'wo' | 'place' | 'pic';

export default function App() {
  const [records, setRecords] = useState<BlueFileRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchType, setSearchType] = useState<SearchType>('wo');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedArea, setSelectedArea] = useState('A');
  const [selectedRecord, setSelectedRecord] = useState<BlueFileRecord | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [highlightPlace, setHighlightPlace] = useState<string | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  }, []);

  const fetchRecords = useCallback(async () => {
    setLoading(true);
    setError(null);
    const { data, error: fetchError } = await supabase
      .from('blue_file_records')
      .select('*')
      .order('area')
      .order('rack')
      .order('position')
      .order('slot');

    if (fetchError) {
      setError(fetchError.message);
      setRecords([]);
    } else {
      setRecords(data as BlueFileRecord[]);
    }
    setLoading(false);
  }, []);

  useEffect(() => { fetchRecords(); }, [fetchRecords]);

  useEffect(() => {
    if (records.length > 0 && !records.some((r) => r.area === selectedArea)) {
      setSelectedArea(records[0].area);
    }
  }, [records, selectedArea]);

  const handleSearch = () => {
    const q = searchQuery.trim().toUpperCase();
    if (!q) { setHighlightPlace(null); return; }

    if (searchType === 'wo') {
      const match = records.find((r) => r.wo.toUpperCase().includes(q));
      if (match) {
        setSelectedArea(match.area);
        setHighlightPlace(match.place);
        setSelectedRecord(match);
        showToast(`Found: ${match.wo} at ${match.place}`);
      } else {
        showToast(`No record found for WO "${searchQuery}"`, 'error');
      }
    } else if (searchType === 'place') {
      const normalized = q.replace(/\s+/g, '');
      const parsed = parsePlace(normalized);
      if (!parsed) { showToast('Invalid format. Use like A16R-001', 'error'); return; }
      const match = records.find((r) => r.place.toUpperCase() === parsed.place.toUpperCase());
      setSelectedArea(parsed.area);
      setHighlightPlace(parsed.place);
      if (match) {
        setSelectedRecord(match);
        showToast(`Found: ${match.wo} at ${parsed.place}`);
      } else {
        showToast(`${parsed.place} is empty`, 'error');
      }
    } else {
      // PIC search — find all matching, show first and list count
      const matches = records.filter((r) => (r.pic ?? '').toUpperCase().includes(q));
      if (matches.length > 0) {
        const match = matches[0];
        setSelectedArea(match.area);
        setHighlightPlace(match.place);
        setSelectedRecord(match);
        showToast(`Found ${matches.length} record${matches.length !== 1 ? 's' : ''} for PIC "${searchQuery}"`);
      } else {
        showToast(`No records found for PIC "${searchQuery}"`, 'error');
      }
    }
  };

  const handleSaveFile = async (input: BlueFileInput, id?: string): Promise<boolean> => {
    if (id) {
      const { error: updateError } = await supabase.from('blue_file_records').update(input).eq('id', id);
      if (updateError) { showToast(updateError.message, 'error'); return false; }
      showToast('Record updated successfully');
    } else {
      const { error: insertError } = await supabase.from('blue_file_records').insert(input);
      if (insertError) { showToast(insertError.message, 'error'); return false; }
      showToast('File added successfully');
    }
    await fetchRecords();
    return true;
  };

  const handleDeleteFile = async (id: string): Promise<boolean> => {
    const { error: deleteError } = await supabase.from('blue_file_records').delete().eq('id', id);
    if (deleteError) { showToast(deleteError.message, 'error'); return false; }
    showToast('Record removed — slot is now empty');
    setSelectedRecord(null);
    await fetchRecords();
    return true;
  };

  const handleMoveFile = async (id: string, newPlace: string): Promise<boolean> => {
    const parsed = parsePlace(newPlace);
    if (!parsed) { showToast('Invalid place format', 'error'); return false; }
    const { error: moveError } = await supabase
      .from('blue_file_records')
      .update({ place: parsed.place, area: parsed.area, rack: parsed.rack, position: parsed.position, slot: parsed.slot })
      .eq('id', id);
    if (moveError) { showToast(moveError.message, 'error'); return false; }
    showToast(`File moved to ${parsed.place}`);
    await fetchRecords();
    return true;
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Header onAddClick={() => setShowAddModal(true)} onImportClick={() => setShowImportModal(true)} />

      <div className="sticky top-16 z-20 border-b border-slate-800 bg-slate-900/95 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <SearchBar
            searchType={searchType}
            setSearchType={setSearchType}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onSearch={handleSearch}
          />
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
        {error && (
          <div className="mt-4 rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-300">{error}</div>
        )}

        <div className="mt-4">
          <Dashboard records={records} loading={loading} />
        </div>

        {loading ? (
          <div className="mt-12 flex flex-col items-center justify-center text-slate-500">
            <div className="h-10 w-10 animate-spin rounded-full border-2 border-slate-700 border-t-sky-400" />
            <p className="mt-4 text-sm">Loading rack map...</p>
          </div>
        ) : records.length === 0 ? (
          <div className="mt-12 flex flex-col items-center justify-center rounded-2xl border border-slate-800 bg-slate-900/50 p-12 text-center">
            <FileSpreadsheet className="h-12 w-12 text-slate-600" />
            <h3 className="mt-4 text-lg font-semibold text-slate-300">No blue file records yet</h3>
            <p className="mt-2 max-w-md text-sm text-slate-500">
              Import an Excel file or add a file manually to start tracking your storage locations.
            </p>
            <div className="mt-6 flex gap-3">
              <button onClick={() => setShowImportModal(true)} className="inline-flex items-center gap-2 rounded-lg bg-slate-800 px-5 py-2.5 text-sm font-medium text-slate-300 transition hover:bg-slate-700">
                <FileSpreadsheet className="h-4 w-4" /> Import Excel
              </button>
              <button onClick={() => setShowAddModal(true)} className="rounded-lg bg-sky-500 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-sky-400">
                Add File Manually
              </button>
            </div>
          </div>
        ) : (
          <RackMap
            records={records}
            selectedArea={selectedArea}
            onSelectArea={(area) => { setSelectedArea(area); setHighlightPlace(null); }}
            highlightPlace={highlightPlace}
            onSlotClick={(record) => { if (record) setSelectedRecord(record); }}
          />
        )}
      </main>

      {selectedRecord && (
        <FileDetailModal
          record={selectedRecord}
          allRecords={records}
          onClose={() => setSelectedRecord(null)}
          onEdit={async (input, id) => { const ok = await handleSaveFile(input, id); if (ok) setSelectedRecord(null); return ok; }}
          onDelete={async (id) => { return await handleDeleteFile(id); }}
          onMove={async (id, newPlace) => { const ok = await handleMoveFile(id, newPlace); if (ok) setSelectedRecord(null); return ok; }}
        />
      )}

      {showAddModal && (
        <AddFileModal
          allRecords={records}
          defaultArea={selectedArea}
          onClose={() => setShowAddModal(false)}
          onSave={async (input) => { const ok = await handleSaveFile(input); if (ok) setShowAddModal(false); return ok; }}
        />
      )}

      {showImportModal && (
        <ImportModal
          existingRecords={records}
          onClose={() => setShowImportModal(false)}
          onImported={fetchRecords}
          showToast={showToast}
        />
      )}

      {toast && <Toast message={toast.message} type={toast.type} />}
    </div>
  );
}
