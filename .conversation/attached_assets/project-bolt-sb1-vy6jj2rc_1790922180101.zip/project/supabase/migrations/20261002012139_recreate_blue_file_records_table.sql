/*
# Recreate blue_files table as blue_file_records for Blue File Management System

## Overview
This table stores blue file records imported from Excel or added manually.
Each record has a "place" code that encodes Area > Rack > Position > Slot (e.g. A16R-011).
The structure is fully dynamic — any Area (A-Z), Rack number, Position (L/M/R), and Slot number
can appear in the data. Nothing is hardcoded.

## New Table
- `blue_file_records`
  - `id` (uuid, primary key)
  - `no` (int) — row number from Excel import
  - `wo` (text, not null, unique) — Work Order number, must be unique across all records
  - `complete` (text) — completion status from Excel
  - `place` (text, not null, unique) — location code like "A16R-001", must be unique (one file per slot)
  - `area` (text, not null) — single letter A-Z, parsed from place
  - `rack` (int, not null) — rack number, parsed from place
  - `position` (text, not null) — L, M, or R, parsed from place
  - `slot` (int, not null) — slot number, parsed from place
  - `date_in` (text) — date from Excel
  - `time_in` (text) — time from Excel
  - `pic` (text) — person in charge from Excel
  - `status` (text, not null, default 'occupied') — one of: 'occupied', 'reserved'
  - `created_at` (timestamptz, default now)
  - `updated_at` (timestamptz, default now)

## Status Logic
- 'occupied' = a blue file physically placed at this location
- 'reserved' = a WO already exists elsewhere OR place already assigned (prevents duplicates)
- Empty slots have NO record — they are simply absent from the table

## Constraints
- UNIQUE on `wo` — prevents duplicate work orders
- UNIQUE on `place` — prevents duplicate slot assignments
- CHECK on `area` matching ^[A-Z]$
- CHECK on `position` IN ('L','M','R')
- CHECK on `status` IN ('occupied','reserved')

## Indexes
- Index on area for rack filtering
- Index on wo for search
- Index on place for search
- Index on status for dashboard counts
- Index on (area, rack, position, slot) for rack map queries

## Security
- Single-tenant app, no auth — RLS with anon+authenticated full CRUD
*/

DROP TABLE IF EXISTS blue_files CASCADE;

CREATE TABLE IF NOT EXISTS blue_file_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  no int,
  wo text NOT NULL,
  complete text,
  place text NOT NULL,
  area text NOT NULL CHECK (area ~ '^[A-Z]$'),
  rack int NOT NULL CHECK (rack > 0),
  position text NOT NULL CHECK (position IN ('L', 'M', 'R')),
  slot int NOT NULL CHECK (slot > 0),
  date_in text,
  time_in text,
  pic text,
  status text NOT NULL DEFAULT 'occupied' CHECK (status IN ('occupied', 'reserved')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(wo),
  UNIQUE(place)
);

CREATE INDEX IF NOT EXISTS idx_bfr_area ON blue_file_records (area);
CREATE INDEX IF NOT EXISTS idx_bfr_wo ON blue_file_records (wo);
CREATE INDEX IF NOT EXISTS idx_bfr_place ON blue_file_records (place);
CREATE INDEX IF NOT EXISTS idx_bfr_status ON blue_file_records (status);
CREATE INDEX IF NOT EXISTS idx_bfr_location ON blue_file_records (area, rack, position, slot);

ALTER TABLE blue_file_records ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_bfr" ON blue_file_records;
CREATE POLICY "anon_select_bfr" ON blue_file_records FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_bfr" ON blue_file_records;
CREATE POLICY "anon_insert_bfr" ON blue_file_records FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_bfr" ON blue_file_records;
CREATE POLICY "anon_update_bfr" ON blue_file_records FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_bfr" ON blue_file_records;
CREATE POLICY "anon_delete_bfr" ON blue_file_records FOR DELETE
  TO anon, authenticated USING (true);

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_bfr_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_bfr_updated_at ON blue_file_records;
CREATE TRIGGER trg_bfr_updated_at
  BEFORE UPDATE ON blue_file_records
  FOR EACH ROW EXECUTE FUNCTION update_bfr_updated_at();
