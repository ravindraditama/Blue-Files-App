/*
# Create blue_files table for Blue File Monitoring

## Overview
This table stores blue file documents placed at specific physical storage locations.
Each file occupies one unique slot in a rack system. The location hierarchy is:
Rack Letter (A-Q) > Rack Number (01-18) > Position (L/M/R) > Slot (001-010).

## New Tables
- `blue_files`
  - `id` (uuid, primary key)
  - `drawing_number` (text, not null, unique) — the drawing/document identifier, searchable
  - `title` (text) — optional document title
  - `description` (text) — optional description of the file contents
  - `rack_letter` (text, not null) — rack identifier A through Q
  - `rack_number` (int, not null) — sub-rack number 1 through 18
  - `position` (text, not null) — position within slot: L (Left), M (Middle), R (Right)
  - `slot_number` (int, not null) — slot number 1 through 10
  - `created_at` (timestamptz, default now)
  - `updated_at` (timestamptz, default now)

## Constraints
- Unique combination of (rack_letter, rack_number, position, slot_number) — one file per slot
- CHECK constraints validate rack_letter in A-Q, rack_number 1-18, position in L/M/R, slot_number 1-10

## Indexes
- Index on drawing_number for fast search
- Index on location columns for fast location-based queries
- Index on rack_letter for rack filtering

## Security
- Single-tenant app with no authentication — RLS enabled with anon+authenticated full CRUD
- All data is intentionally shared/public among operators
*/

CREATE TABLE IF NOT EXISTS blue_files (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  drawing_number text NOT NULL,
  title text,
  description text,
  rack_letter text NOT NULL CHECK (rack_letter ~ '^[A-Q]$'),
  rack_number int NOT NULL CHECK (rack_number >= 1 AND rack_number <= 18),
  position text NOT NULL CHECK (position IN ('L', 'M', 'R')),
  slot_number int NOT NULL CHECK (slot_number >= 1 AND slot_number <= 10),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(rack_letter, rack_number, position, slot_number)
);

-- Indexes for search performance
CREATE INDEX IF NOT EXISTS idx_blue_files_drawing_number ON blue_files (drawing_number);
CREATE INDEX IF NOT EXISTS idx_blue_files_location ON blue_files (rack_letter, rack_number, position, slot_number);
CREATE INDEX IF NOT EXISTS idx_blue_files_rack_letter ON blue_files (rack_letter);

-- Enable RLS
ALTER TABLE blue_files ENABLE ROW LEVEL SECURITY;

-- Policies: single-tenant, no auth, data is shared
DROP POLICY IF EXISTS "anon_select_blue_files" ON blue_files;
CREATE POLICY "anon_select_blue_files" ON blue_files FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_blue_files" ON blue_files;
CREATE POLICY "anon_insert_blue_files" ON blue_files FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_blue_files" ON blue_files;
CREATE POLICY "anon_update_blue_files" ON blue_files FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_blue_files" ON blue_files;
CREATE POLICY "anon_delete_blue_files" ON blue_files FOR DELETE
  TO anon, authenticated USING (true);

-- Auto-update updated_at on row change
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_blue_files_updated_at ON blue_files;
CREATE TRIGGER trg_blue_files_updated_at
  BEFORE UPDATE ON blue_files
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
